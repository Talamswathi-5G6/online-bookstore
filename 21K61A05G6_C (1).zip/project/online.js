 // Sample book data
 const books = [
    { title: "THE GREAT GATSBY", author: "F.SCOTT.fitgerald", price:34.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRwYGqt4UKKwCThnPIT5PbD2JHen-9NfY20Ow&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQPXafjmh2e49aix_MxNjS3MmiZBnyvG1OcqA&usqp=CAU"},
    { title: "Book 3", author: "Author 3", price: 42.49, image: "https://i.pinimg.com/originals/dd/a5/ba/dda5ba79b078f466b5b38ea750eabe38.jpg" },
    { title: "Book 4", author: "Author 4", price: 49.99, image: "https://i.pinimg.com/originals/49/ed/e5/49ede50560681c25baf9dac5c5a69ed9.jpg" },
    // Add more books with images here
    { title: "your ", author: "Author 1", price: 12.99, image: "https://imaginationsoup.net/wp-content/uploads/2020/05/Finn-and-the-Intergalactic-Lunchbox-1356x2048.jpg" },
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image: "https://www.blackgate.com/wp-content/uploads/2020/11/Escape-Pod-The-Science-Fiction-Anthology.jpg" },
    // Add more books with images here
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRgMpSmRdYAK2wpbum4tKHDb3jah4JCFkMQyg&usqp=CAU"},
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvJX2O8uWDWtW5jYLDdaxIr7aFm6JuIjjymA&usqp=CAU"},
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRx5q6JtxPtYuzib5DckKEWf0jQeEzmnV6GeA&usqp=CAU"},
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS3pka3LzNkyCEm7JRt6rhPI4NeeYvp_jpJDQ&usqp=CAU"},
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQCQ8OAAlBuVwOqGJvaG34Uof-AQ09FrWtnDg&usqp=CAU"},
    { title: "Your Book Title 2", author: "Author 2", price: 9.49, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRuVydd9G9E1JRqXqvaO3WGKEh7unz068QWAA&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRkmdsfBFkhtKcnttr0bamfFkYz5YoQeA_Mg&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRP0lS4Lya5s74o2PLlWTEasWy7MyX4T64aNQ&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTaptF1AZJtI18NSqUW_OMubT5ON787ljt9Dw&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRXI-qNEvFknCPIzbliT7gQ9Pt_R-fTAsn_iw&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5MQZ_iezzPnPvoLOJBetSPqU4dgKKgwgFxw&usqp=CAU"},
    { title: "catch-22", author: "joseph heller", price: 15.99, image:"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQowu27uvrvVWP4TYgscspjiGxpd11S2v1wbLH3KAlZcynNIR2DLUCgADx1-HoG4R4e4GY&usqp=CAU+"},
  ];

  // Initialize the cart
  let cartItems = [];

  // Function to render the books
  function renderBooks() {
    const booksContainer = document.getElementById("books");
    booksContainer.innerHTML = "";

    books.forEach((book, index) => {
      const bookElement = document.createElement("div");
      bookElement.classList.add("book");
      bookElement.innerHTML = `
        <img src="${book.image}" alt="${book.title}">
        <span>${book.title} - ${book.author} ($${book.price.toFixed(2)})</span>
        <button onclick="addToCart(${index})">Add to Cart</button>
      `;
      booksContainer.appendChild(bookElement);
    });
  }

  // Function to render the shopping cart
  function renderCart() {
    const cartContainer = document.getElementById("cart");
    cartContainer.innerHTML = "";

    cartItems.forEach((item, index) => {
      const cartItemElement = document.createElement("div");
      cartItemElement.classList.add("cart-item");
      cartItemElement.innerHTML = `
        <span>${item.title} - ${item.author} ($${item.price.toFixed(2)})</span>
        <button onclick="removeFromCart(${index})">Remove</button>
      `;
      cartContainer.appendChild(cartItemElement);
    });
  }

  // Function to add a book to the cart
  function addToCart(bookIndex) {
    const selectedBook = books[bookIndex];
    cartItems.push(selectedBook);
    renderCart();
  }

  // Function to remove a book from the cart
  function removeFromCart(cartIndex) {
    cartItems.splice(cartIndex, 1);
    renderCart();
  }

  // Initial rendering
  renderBooks();
  renderCart();